# Pattern Library｜语言模式与语境

Pattern 保存可实例化的语言形式及适用条件；实际 utterance 还绑定主体、媒介、前文、状态和关系。Pattern 与 Operator / Protocol 是多对多，句子形式不能唯一决定功能。

为避免两套手工编辑的正文，LP01—LP34 的主句与变体直接维护在算子卡片；本页提供用途映射与组合模式。

## 模式索引

| 模式 | 正文来源 | 主要适用条件 |
| --- | --- | --- |
| LP01 | [OP01](OPERATORS.md#op01) | 能辨认 X 及相关结果 Y |
| LP02 | [OP02](OPERATORS.md#op02) | 原目的与当前手段能被区别 |
| LP03 | [OP03](OPERATORS.md#op03) | 原命题含义明确 |
| LP04 | [OP04](OPERATORS.md#op04) | 知道暂时解除哪项约束 |
| LP05 | [OP05](OPERATORS.md#op05) | 有基本事件记录与不确定性 |
| LP06 | [OP06](OPERATORS.md#op06) | 两个对象或状态可进入对照 |
| LP07 | [OP07](OPERATORS.md#op07) | 至少两个可指涉对象 |
| LP08 | [OP08](OPERATORS.md#op08) | 主体正在作比较判断 |
| LP09 | [OP09](OPERATORS.md#op09) | 对象模糊且需要具体判断 |
| LP10 | [OP10](OPERATORS.md#op10) | 范围不清或搜索成本过大 |
| LP11 | [OP11](OPERATORS.md#op11) | 单一方案、解释或未来方向不足 |
| LP12 | [OP12](OPERATORS.md#op12) | 已有一个可明确的判断 |
| LP13 | [OP13](OPERATORS.md#op13) | 主张与材料可定位 |
| LP14 | [OP14](OPERATORS.md#op14) | 命题范围明确 |
| LP15 | [OP15](OPERATORS.md#op15) | 主体、候选与情境明确 |
| LP16 | [OP16](OPERATORS.md#op16) | 已有或正在形成偏好方向 |
| LP17 | [OP17](OPERATORS.md#op17) | 主体有一个期望状态 |
| LP18 | [OP18](OPERATORS.md#op18) | 评价对象与用途可澄清 |
| LP19 | [OP19](OPERATORS.md#op19) | 有候选、标准和至少部分材料 |
| LP20 | [OP20](OPERATORS.md#op20) | 需要当前决策，已有足够或明示不足信息 |
| LP21 | [OP21](OPERATORS.md#op21) | 目标或选择已明确 |
| LP22 | [OP22](OPERATORS.md#op22) | 有一个判断或操作过程 |
| LP23 | [OP23](OPERATORS.md#op23) | 有需要共享的具体内容 |
| LP24 | [OP24](OPERATORS.md#op24) | 双方解释或工作范围不同 |
| LP25 | [OP25](OPERATORS.md#op25) | 存在可表达的不一致 |
| LP26 | [OP26](OPERATORS.md#op26) | 对象、渠道和所求行为明确 |
| LP27 | [OP27](OPERATORS.md#op27) | 有主体、受益方与适用规则 |
| LP28 | [OP28](OPERATORS.md#op28) | 已有任务方向和相关角色 |
| LP29 | [OP29](OPERATORS.md#op29) | 需要行动安排，规则来源可查 |
| LP30 | [OP30](OPERATORS.md#op30) | 有旧有效安排与新情况 |
| LP31 | [OP31](OPERATORS.md#op31) | 存在需要重复处理的情境及有权角色 |
| LP32 | [OP32](OPERATORS.md#op32) | 主体已采纳目标且能执行动作 |
| LP33 | [OP33](OPERATORS.md#op33) | 有可追溯材料或待展开标签 |
| LP34 | [OP34](OPERATORS.md#op34) | 有实例与可比较结构 |

<a id="lp35"></a>
## LP35. Desired-Change Micro-Protocol｜“你希望什么变得不同？”

这是可压缩 Desired-Change Micro-Protocol 的模式。可能调用 OP09 当前状态具体化、OP06 对照、OP11 替代生成、OP15 偏好与 OP16 期望状态构造；不是只执行 Difference。

若主体已有期望状态，只需澄清或确认，不再重走全部链。若只能说不想要什么，先明确回避对象，再生成替代；若不知道当前状态，先获取材料。单次回答也可能只完成其中一部分。

<a id="lp36"></a>
## LP36. Completion Clarification｜“你说的完成，具体意味着什么？”

可能执行 OP09 具体化、OP18 标准形成、OP24 含义对齐，或 OP28 将标准绑定到任务。只看到问句不能确定归属；检查变化发生于内部判断、主体间理解还是任务约定。

## 调整原则

1. 不在问题中预填未经确认的目标或立场。
2. 允许“不知道”“不同意”“无法比较”和“需要查证”。
3. 区分请求理解、请求评价和请求采纳，不用同一句“你明白吧”代替。
4. 对术语歧义使用例子和反例；对事实未知获取材料，不能靠不断换问法制造答案。
5. 对 AI 使用可检查的文本和行为条件；对人保留主体确认与意义协商。
