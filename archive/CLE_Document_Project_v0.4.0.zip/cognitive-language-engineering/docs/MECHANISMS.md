# Mechanism Map｜过程解释与映射

机制家族是用于组织解释的索引，不把一个家族当作单一已测得心理过程。模型中的映射均是工程候选；有文献支持的局部现象另列来源，不能把其等级直接赋给全部组件。

<a id="me01"></a>
## ME01. Attention Direction / Search Allocation

语言提示将任务注意指向特定对象，并限定接下来搜索哪些信息。映射 C-P1/C-P9/C-P13、R-P1。使用问句可尝试这种变化，但“每个问题必然重新分配注意”的强命题不采用。本版为 E0 过程假设；检查聚焦迹象和遗漏成本。

<a id="me02"></a>
## ME02. Comparison / Categorization / Structural Mapping

分别涉及对照、识别特征和映射关系，不假定三者是同一机制。映射 R-P2/R-P3/R-P4、C-P3—C-P7。提出差异／相似请求后，检查是否产生可使用区别及错误类推。本版映射 E0；命名基本认知活动不等于解释了其神经或计算过程。

<a id="me03"></a>
## ME03. Encoding / Externalization / Retrieval

分别组织表达、外部记录和重新调用材料。映射 R-P5/R-P6/R-P7、C-P2。外化可以改变任务的信息处理要求；[SRC07](sources/VERIFIED_SOURCES.md#src07)提供相关综述。本版不据此宣称写下来一定提高记忆或理解；编码、压缩和概念命名的具体映射仍 E0。

<a id="me04"></a>
## ME04. Metacognitive Monitoring / Confidence Representation

注意自身判断过程、依据和不确定性。映射 C-P2/C-P10/C-P19/C-P20、C-C11/C-C12。[SRC08](sources/VERIFIED_SOURCES.md#src08)区分元认知偏差、敏感性与效率，支持分开测量，而非以自述替代指标。操作后的可靠性改善仍需实验或结果记录。

<a id="me05"></a>
## ME05. Contextual Valuation / Framing

候选、目的和表述参与主观评价。映射 C-P7/C-P15/C-P17/C-P21、C-C8/C-C9/C-C10。[SRC02](sources/VERIFIED_SOURCES.md#src02)、[SRC03](sources/VERIFIED_SOURCES.md#src03)、[SRC12](sources/VERIFIED_SOURCES.md#src12)支持局部框架、偏好构造与决策一致化研究。不从一个问法反应确定主体稳定偏好，也不把改变倾向等同于提高判断质量。

<a id="me06"></a>
## ME06. Alternative Generation / Counterfactual Construction

调用记忆、类比或情境改写生成候选。映射 C-P8/C-P11/C-P12/C-P16。Removal 等算子属于此类工程假设。想象 X 不存在时仍有结果，不能单独证明 X 在现实中非必要；反事实结果依赖模型。效果与必要性推断均按 E0 处理。

<a id="me07"></a>
## ME07. Prospective Simulation

组织未来事件或状态表征；episodic 与 semantic 表征需区分。映射 C-P16、C-C6/C-C13。[SRC04](sources/VERIFIED_SOURCES.md#src04)支持未来事件模拟在指定跨期选择任务中的效果，[SRC05](sources/VERIFIED_SOURCES.md#src05)提供概念基础。它们不验证所有期望状态构造，亦不证明理想画面自动促成行动。

<a id="me08"></a>
## ME08. Explanation / Evidence Appraisal / Model Testing

分别组织候选解释、证据相关性与区分竞争解释的测试。映射 C-P11/C-P12/C-P14/C-P19、C-C2/C-C3/C-C9/C-C11。需用关系、预测、反例和实际观察，而不是把“能解释”当“是真的”。[SRC09](sources/VERIFIED_SOURCES.md#src09)支持特定社会判断任务的反向考虑干预；不保证普遍去偏。[SRC10](sources/VERIFIED_SOURCES.md#src10)仅题录确认，不作为本版效果依据。

<a id="me09"></a>
## ME09. Goal Regulation / Adoption / Planning

分别组织目标采纳、资源投入、手段计划和线索—行为绑定。映射 C-P18/C-P21、C-C7/C-C10/C-C13/C-C14。[SRC06](sources/VERIFIED_SOURCES.md#src06)支持 goal intention 与 implementation intention 的区分；[SRC11](sources/VERIFIED_SOURCES.md#src11)为目标设置研究索引。C-P18 作为 CLE 独立接口仍 E0，不等同于验证了一个单一目标采纳机制。

<a id="me10"></a>
## ME10. Grounding / Interactional Repair

共同提供和检查理解证据，按目的与媒介修复歧义。映射 I-P1、I-C1—I-C8、B-C2。[SRC01](sources/VERIFIED_SOURCES.md#src01)提供原理论文本依据。共享程度是对任务的充分程度，不是完美一致；CLE 的特定模式、停止条件与错误率仍需检验。

<a id="me11"></a>
## ME11. Situated Interpretation / Pragmatic Inference

根据语境、角色、前文和语言形式理解所指与行为功能。映射 I-C2/I-C3、A-P1、B-C2/B-C3/B-C7。本版作为理论相关过程家族登记；不宣称语言形式足以决定功能。[SRC01](sources/VERIFIED_SOURCES.md#src01)说明理解与互动的关系，但不承担全部语用推理理论。

<a id="me12"></a>
## ME12. Constitutive Rules / Social-State Update

根据有效规则，将请求、承担、认可、授权或关闭事件解释为社会状态更新。映射 M4 全部条目。这里首先是过程与制度规则的工程描述，效果 E0；不是把“承诺形成”再叫作同名机制就得到因果解释。需检查角色、来源、认可与真实执行条件。

## 映射检查

每个映射至少回答：要解释哪个前后变化、提出什么过程、什么观察可支持或推翻、还有什么替代解释、研究材料与当前任务有何差别。无法回答时，保留为未验证假设，不装成机制已经成立。
