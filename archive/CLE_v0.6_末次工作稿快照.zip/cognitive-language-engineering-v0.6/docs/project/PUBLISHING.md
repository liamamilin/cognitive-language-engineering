# 发布在线电子书

完整v0.6仍为工作版，尚未冻结；完整v0.5及结构核心v0.2冻结归档保留。

## 当前发布方式

仓库：[liamamilin/cognitive-language-engineering](https://github.com/liamamilin/cognitive-language-engineering)。已知历史记录：2026-10-01用户网页上传完整v0.6后，[该次提交](https://github.com/liamamilin/cognitive-language-engineering/commit/e604dcefd3f463b807d98c7e53a1134cf5e9f801)的Actions部署成功；这说明当时那批内容上线，不说明后续本地修改已同步。插件写入曾返回403（Resource not accessible by integration），账号具有仓库权限与插件能实际写入是两项不同条件。

2026-10-02本轮为正文审查与修订，未执行远程提交，也未重新核验线上当前版本。署名、阅读体验、概念澄清与本轮理解衔接的待同步文件合并为更新包；这些更新是否已经上线，须以对应提交、Actions与实际页面确认。

Markdown → MkDocs Material → 静态阅读页面 → GitHub Pages。main推送触发`.github/workflows/book.yml`；PR只构建检查，手动运行也可触发部署。源码提交、构建成功与部署成功分别确认，在线地址以部署任务输出为准。

结构核心子体系使用独立阅读模板，输出至`essentials/index.html`；母体系首页“阅读路线”保留入口，子体系保留返回和追溯链接。所有跳转使用相对路径。

## 后续更新

正文以docs为准。修改后同步索引、版本记录与派生检查材料，运行README中的文档检查和严格构建，再提交到main。保留冻结快照与稳定编号；v0.6是否冻结另由用户决定。

仓库Settings → Pages → Build and deployment → Source应选择GitHub Actions。部署失败先查看Actions对应任务的日志，再按失败原因修正或重跑。实际站点URL须从成功部署输出核验，不按地址模式宣称已上线。

网站未配置网页版本选择器；它展示成功部署的提交，不能据本地文件更新推定已经展示最新阅读版。旧版本正文保存在archive。单文件Markdown和HTML阅读副本可通过`python scripts/export_book.py --output-dir reading`重新生成，不手工维护。EPUB/PDF可在正文更稳定时再增加。

## 历史发布记录

此前曾使用云浏览器创建仓库，上传受浏览器运行环境阻塞；随后采用source-import.zip和首次导入工作流，现已核实远程仓库具有v0.5.3源码。本轮不再需要首次导入包。旧导入包和工作流记录保留在Git历史及原仓库，避免改动无关文件。

## 官方参考

- [MkDocs：Deploying your docs](https://www.mkdocs.org/user-guide/deploying-your-docs/)
- [Material for MkDocs：Publishing your site](https://squidfunk.github.io/mkdocs-material/publishing-your-site/)
- [GitHub：Deploying your website automatically](https://docs.github.com/en/get-started/start-your-journey/deploying-your-website-automatically)
