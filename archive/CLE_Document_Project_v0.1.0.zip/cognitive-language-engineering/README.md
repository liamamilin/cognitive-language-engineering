# Cognitive Language Engineering｜认知语言工程

持续维护的 Markdown 文档项目，用于研究如何主动设计和使用语言，使语言更有效地服务于思考、表达、影响、协作与行动。

项目初始化版本：`project-v0.1.0`（2026-10-01）。这个版本号描述项目快照；Core Spec 自身的 `v0.3` 与各模型版本独立保留。

## 从这里开始

- [阅读入口](docs/index.md)
- [当前进度](docs/project/STATUS.md)
- [维护约定](docs/project/MAINTENANCE.md)
- [初始基线与待对齐项](docs/project/BASELINE.md)
- [变更记录](docs/project/CHANGELOG.md)
- [GitHub 与在线电子书发布](docs/project/PUBLISHING.md)

## 本地阅读

在本目录执行：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m mkdocs serve
```

浏览器打开终端显示的地址。生成静态电子书：

```bash
python -m mkdocs build --strict
```

输出目录为 `site/`。在线电子书直接由 `docs/` 生成，正文只有一套来源。当前没有生成 EPUB 或 PDF。

## 目录约定

| 路径 | 职责 |
| --- | --- |
| `docs/PURPOSE.md` | 核心目的，原始附件内容 |
| `docs/CORE_SPEC.md` | 核心规范，原始 v0.3 |
| `docs/models/` | M1—M4 初始正式基线 |
| `docs/research/` | 候选定义、机制映射与未决问题 |
| `docs/project/` | 状态、维护规则、版本记录、发布说明 |
| `docs/decisions/` | 重要结构决策及其理由 |
| `docs/sources/` | 文献索引和证据核验记录 |
| `mkdocs.yml` | 在线电子书的目录与显示配置 |
| `.github/workflows/` | 构建检查与 GitHub Pages 发布配置 |

研究目录放在 `docs/` 内，便于同一阅读入口展示；其候选状态与正式基线明确区分。

## 版本管理

解压后可在本目录建立本地 Git 仓库：

```bash
git init -b main
git add .
git commit -m "Initialize CLE documentation project"
git tag project-v0.1.0
```

仓库身份使用你自己的 Git 配置。GitHub 仓库及在线链接将在后续建立和发布，本项目包不包含已经发布的地址。
