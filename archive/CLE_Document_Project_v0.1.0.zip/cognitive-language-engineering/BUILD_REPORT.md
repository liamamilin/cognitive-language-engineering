# 初始化验证

日期：2026-10-01。

- `python -m mkdocs build --strict`：通过，退出码 0。
- MkDocs：1.6.1；Material：9.7.7；依赖版本已固定。
- 六份基线正文与上传源文件逐字节一致，SHA-256 记录在 `baseline-manifest.json`。
- 所有 Markdown 阅读页纳入导航；研究稿保持候选状态，未直接回写正式 Registry。
- 本地生成静态阅读页面，未运行 GitHub 远程工作流，未发布在线链接。

发布到 GitHub 后仍需完成仓库 Pages 设置，并确认工作流实际成功。此包不是 EPUB 或 PDF 文件。
