# C-C7 目标形成｜候选研究稿

整理日期：2026-10-01。状态：Draft。C-P18 为候选编号，尚未回写 M2。本文保存工作定义和审查问题，不继承对话中未核验的证据等级。

## 状态变化

**Desired Change → Goal Representation**。

工作定义：将期望变化组织为主体采纳、准备追求的目标表征，并按任务需要逐步明确对象、范围和判断条件。

## 核心分界

| 概念 | 回答的问题 |
| --- | --- |
| Desired State | 世界希望变成什么样？ |
| Goal | 我采纳并准备追求哪个状态？ |
| Means | 有哪些实现手段？ |
| Plan | 如何组织实现过程？ |
| Implementation Intention | 在什么情境出现时执行什么行为？ |
| M4 Commitment | 向谁形成了什么被承认的社会义务？ |
| Task | 哪个行动单元需要被完成？ |

例子：“离开 Mac 后仍能方便执行高频操作”可以是目标方向；App、PWA、快捷指令等是实现候选。制作某个交付物也可以在项目语境中成为合法子目标，关键是保留它与上层目的的关系。

## C-P18 Goal Adoption

候选状态变化：**Preferred / Desired State → Adopted Goal**。

它区分“这个状态更好”和“我要追求这个状态”。此处的 adoption／commitment 指 M2 内部的目标采纳和投入倾向，不自动形成 M4 社会承诺。

机制候选：价值与期望评估、可行性评估、动机相关性和目标投入。Goal Intention 与 Implementation Intention 的区分是相关研究方向，但文献待核验。

## 最小结构与分辨率

对话提出的结构候选为：**Target Object + Desired State + Adoption + Boundary + Criterion**。

仍需审查：Boundary 与 Criterion 是一切目标的必要构成，还是目标可操作化时需要补全的字段？不能同时声称“所有目标必须有标准”，又把它作为可省略的后续步骤。

目前允许区分：

- 最小目标采纳：主体采纳一个可识别的期望状态。
- 目标表征完善：逐步绑定对象、边界和判断条件。
- 目标规格化：在任务需要时进一步补充时间、数量与可验证指标。

不要将 Goal Formation 自动等同于 SMART 化。具体程度应匹配任务和当前认知阶段。

## 复用与新增

| 条目 | 当前处理 |
| --- | --- |
| C-P18 Goal Adoption | 唯一保留的新 Primitive 候选，待审查 |
| C-P13 Boundary Formation | 优先复用 |
| C-P15 Prioritization | 多目标竞争时按需复用 |
| C-C8 Criteria Formation | 用于标准形成，尚待研究 |
| 对话提出的 C-P19 Target Binding | 暂不登记，需检查与已有过程的关系 |
| 对话提出的 C-P20 Boundary Binding | 暂不登记，优先复用 C-P13 |
| 对话提出的 C-P21 Criterion Attachment | 暂不登记，待 C-C8 澄清 |

目标采纳、边界评估、优先级和标准形成可能相互反馈，不固定为唯一线性顺序。复杂 Composite 可以调用已有 Composite，不要求所有步骤都立即拆成新的 Primitive。

## 方法原则候选

**Minimal Primitive Principle**：拆解 Composite 时优先复用 Registry 已有 Primitive；只有不可替代的状态变化无法表达时，才新增 Primitive。

这是一条待正式接受的方法约定，需在后续分解中用反例检验，避免因过度复用而掩盖真实差异。

## 失效模式候选

- **Means Capture**：某一手段过早占据上层目标的位置，使原本期望改变的状态丢失。
- **Goal Proliferation**：澄清过程生成大量未分层、未排序的目标，反而削弱聚焦。
- **Adoption–Action Confusion**：把已采纳目标当成已经落实行动。
- **Commitment Ambiguity**：混淆内部投入与对外义务。

## 未决问题与下一步

1. 如何判断 Goal Adoption 已发生，而不是主体只是口头表达赞同？
2. 如何定义最小 Goal，避免把完整规格化误当成目标存在条件？
3. 采纳、可行性和边界审查的顺序如何随情境变化？
4. 目标退出／重新采纳是否需要现有 Registry 以外的状态变化？暂不新增编号。
5. 怎样把 M2 的标准表征连接到 M4 验收结构，并保留主体、认可和义务边界？

下一步研究 [C-C8 Criteria Formation](criteria-formation.md)。目标意图、实施意图和 goal–means 文献见[待核验清单](../sources/conversation-citations.md)。
