# C-C6 期望变化形成｜候选研究稿

整理日期：2026-10-01。状态：Draft。根据本次可见的对话整理；C-P16/C-P17 为候选编号，尚未回写 M2。机制说明属于待审查假设，对话引文尚未核验。

## 研究问题

从“我不知道自己要什么”或“我知道哪里不满意”，如何形成“我希望什么发生变化”的表征？

候选 Composite：**Current / Undesired State → Desired Change Representation**。这是多路径过程，不应把一种分析顺序写成所有人的必经链。

## 关键概念分层

| 概念 | 工作定义 | 例子 |
| --- | --- | --- |
| Need | 功能性、心理性或生理性需求／缺口 | 休息、安全 |
| Value | 相对长期重视的状态或原则 | 自主、稳定、公平 |
| Preference | 特定情境下对候选状态的相对倾向 | 更偏好自主性高的工作 |
| Desired State | 能够表征的偏好状态 | 晚上无需即时回应工作消息 |
| Goal | 主体采纳并组织资源追求的状态 | 主动改善晚间工作边界 |

这些关系可相互影响，不假定严格线性。Preference 不等同于 Emotion；情感、推理、记忆、目标和语境都可能参与评价。

## C-P17 Relative Valuation / Preference Formation

候选状态变化：**Represented Alternatives → Directional Preference**。

偏好可以通过已有倾向的激活／报告形成，也可能在当前评价中构造出来。不能把用户回答当成对稳定“真实偏好”的无误读取。

机制候选：Subjective Valuation。支持过程候选：Comparison、Memory Retrieval、Affect／Valence、Goal Activation、Contextual Framing。

输出可包含趋近与回避方向；它们不应简单当作同一正负轴。例如，“我想要自主”与“我不想随时待命”可以提供不同信息。

**差异检测是常见路线，不是偏好形成的必要条件。** 候选状态可以被直接评价，无需先显式列出差异。

风险包括问法、选项集合、呈现顺序与既有选择影响偏好。帮助他人澄清偏好时，还应检查引导是否将协助者的偏好强加给主体。

## C-P16 Desired-State Construction

候选状态变化：**Directional Preference → Represented Preferred State**。

工作定义：将方向性偏好构造成具有可辨认特征的期望状态。最小结构候选为 **Target Object + Preferred State Features**；不要求立即具备精确时限、数量或完整可行性评估。

例子：从“希望少一些打断”，到“晚上八点以后不需要即时回应工作消息，有连续的私人时间”。

可使用具体事件场景，也可使用语义、关系、数量或规则表征。机制候选包括 Prospective Simulation、Episodic Future Thinking 与 Semantic Future Construction；支持过程包括记忆重组、替代生成、抽象和具体化。

必须区分期望状态和实现方案：“离开 Mac 后仍能方便执行常用操作”描述状态，“开发原生 iOS App”描述方案候选。若项目明确把制作 App 本身设为成果目标，则应按该语境判断，不能机械否定。

风险候选：

- **Solution Capture**：过早用某个方案替代期望状态，缩小后续搜索空间。
- **Fantasy Inflation**：表征越来越理想化，却未在后续重新纳入资源和因果约束。
- **Premature Specificity**：将具体化误用为过早锁定实现方式。

期望状态构造本身不保证行动发生；后续需要目标采纳、约束评估和规划等过程。

## 候选路径

| 路径 | 典型过程 | 注意事项 |
| --- | --- | --- |
| 分析／参考路径 | 当前与参考状态 → 比较 → 差异 → 相对评价 → 偏好 → 期望状态 | 若参考已经被偏好，后续评价可能是确认而非全新形成 |
| 生成路径 | 当前状态 → 替代生成 → 候选状态 → 偏好形成 → 期望状态 | 可以不经过显式 Difference Detection |
| 回避路径 | 不满意状态 → 负向评价 → 回避方向 → 替代生成 → 期望状态 | 消除不满意不自动给出唯一偏好替代，必要时继续评价 |

候选复用项：C-P4 Comparative Activation、C-P5 Difference Detection、C-P8 Alternative Generation。

## 语言模式的重新分类

“你希望什么变得不同？”可能同时引导当前状态激活、替代搜索、差异发现、评价和期望状态构造。

因此，它可以被分析为 **Desired-Change Micro-Protocol 的压缩语言模式**，不宜默认等同于单一 Difference Operator。Pattern 与 Operator／Micro-Protocol 的关系需要允许多对多映射；这一点仍待架构审查与回写。

## 证据与未决问题

- 对话中的偏好构造、未来模拟等文献登记在[待核验清单](../sources/conversation-citations.md)。
- 机制家族的研究基础，不等于这一独立 Transition 定义或某句语言干预已经得到验证。
- C-P16/C-P17 是否足够独立、最小，是否存在与已有条目的重复？
- Desired Change 的最终输出应如何表达当前状态与期望状态之间的变化，而不是只得到期望状态？
- 如何区分偏好激活、偏好报告和偏好构造？
- 如何检验一个问句确实诱发了所提议的状态变化？

待回写：C-C6 多路径描述、C-P16/C-P17 候选、Pattern 映射原则。下一连接：[C-C7 目标形成](goal-formation.md)。
