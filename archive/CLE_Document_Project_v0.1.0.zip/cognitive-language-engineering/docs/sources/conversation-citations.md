# 对话引文待核验清单

日期：2026-10-01。所有条目状态：**待核验**。

以下仅从本次可见对话转录。主题是对话赋予来源的用途，不能视为已经验证的题名或研究结论。核验前不据此赋予 E2／E3 等证据等级。

| 来源标识 | 对话中的用途 |
| --- | --- |
| [PMID 26302010](https://pubmed.ncbi.nlm.nih.gov/26302010/) | 偏好构造、目标与情境影响 |
| [PMID 39264680](https://pubmed.ncbi.nlm.nih.gov/39264680/) | 趋近／回避、存在／缺失的区别 |
| [PMID 10329299](https://pubmed.ncbi.nlm.nih.gov/10329299/) | 评价顺序效应 |
| [PMID 15102143](https://pubmed.ncbi.nlm.nih.gov/15102143/) | 选择后的重新评价 |
| [PMID 11728911](https://pubmed.ncbi.nlm.nih.gov/11728911/) | 未来事件模拟 |
| [PMID 9572006](https://pubmed.ncbi.nlm.nih.gov/9572006/) | 结果模拟与过程模拟 |
| [PMID 34843367](https://pubmed.ncbi.nlm.nih.gov/34843367/) | 未来思维与跨期选择，及对话所述汇总数量 |
| [PMID 29130061](https://pubmed.ncbi.nlm.nih.gov/29130061/) | 记忆材料与未来构造 |
| [PMID 37725751](https://pubmed.ncbi.nlm.nih.gov/37725751/) | 未来思维的任务匹配与边界 |
| [OUP 章节 400777985](https://academic.oup.com/book/45852/chapter-abstract/400777985) | Goal Systems Theory、goal–means 与多手段结构 |
| [DOI 10.1016/S0065-2601(06)38002-1](https://doi.org/10.1016/S0065-2601%2806%2938002-1) | Goal Intention／Implementation Intention 区分、效果与对话所述测试数量 |

初始化研究稿没有将对话中的实验数量或效应量作为已验证事实写入正文。后续核验应确认题名与内容，并建立具体主张、原文位置、支持程度和局限的记录。
