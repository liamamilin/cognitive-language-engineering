# 认知语言工程 Core Spec v0.3

## 0. 文档定位

本文档是“认知语言工程”（Cognitive Language Engineering, CLE）的核心规范文档。

它不是教材，不追求穷尽语言学、认知科学、修辞学、心理学或人工智能中的全部相关知识。

它的作用是：

1. 定义认知语言工程研究什么、不研究什么；
    
2. 冻结核心概念及其层级关系；
    
3. 建立可持续扩展的知识架构；
    
4. 为后续 Mechanism Library、Operator Library、Protocol Library 提供统一接口；
    
5. 为实验、文章、课程、产品和未来书籍提供母结构。
    

当前版本：**v0.3**

当前状态：**Architecture Freeze Candidate**

---

# 1. 核心目的

认知语言工程的核心目的，是：

> **提升人对语言的主动控制能力，使语言更有效地服务于人的认知、表达、协作与行动。**

更简洁地说：

> **研究如何更好地使用语言，以更好地思考、表达、影响与行动。**

其中：

- **思考**：发现问题、形成意图、比较、抽象、推理、判断、决策；
    
- **表达**：把内部状态准确地外化给自己、他人或机器；
    
- **影响**：改变他人的注意、理解、判断与行为，同时尊重其自主性；
    
- **行动**：通过请求、承诺、规则、任务、协议等语言行为推动现实变化。
    

认知语言工程不以“解释语言本身”为最终目的。

语言学、认知科学、心理学、修辞学、哲学、教育学、HCI、Prompt Engineering 等知识，只有在能够帮助人**更好地使用语言**时，才进入认知语言工程的核心体系。

---

# 2. 基本立场

认知语言工程把语言同时视为：

1. **表征工具**  
    用于描述现实和内部经验。
    
2. **认知工具**  
    用于组织、调用和调节思维过程。
    
3. **交互接口**  
    用于人与人、人与 AI 之间建立共同理解。
    
4. **行动工具**  
    用于请求、承诺、协调、定义规则和驱动任务。
    
5. **可设计系统**  
    语言形式不是只能被动使用，而可以被有意识地设计、组合、测试和优化。
    

因此，本体系的核心问题不是：

> “语言是什么？”

而是：

> **“为了人的目的，我们应当怎样设计和使用语言？”**

---

# 3. 总体架构

认知语言工程分为两个相互连接的体系。

## 3.1 Explanation Stack｜解释栈

回答：

> **为什么语言能够产生这些效果？**

结构为：

**Principle → Model → Mechanism**

即：

**原则 → 模型 → 机制**

---

## 3.2 Engineering Stack｜工程栈

回答：

> **我们具体怎样使用语言完成任务？**

结构为：

**Task → Operator → Pattern → Protocol → Application → Evaluation**

即：

**任务 → 算子 → 语言模式 → 协议 → 应用 → 评估**

---

## 3.3 两个体系的连接

Mechanism 与 Operator 之间不是一对一关系，而是网状映射。

一个机制可以支持多个算子。

例如：

**Counterfactual Simulation**  
可以支持：

- Removal Operator
    
- Replacement Operator
    
- Inversion Operator
    
- Constraint Release Operator
    

反过来，一个算子也可能同时调用多个机制。

例如：

**Difference Operator**

可能同时调用：

- Comparison
    
- Attention Direction
    
- Difference Search
    

因此：

> **Operator 是解释体系与工程体系之间的主要桥梁。**

---

# 4. 核心概念定义

## 4.1 Principle｜原则

原则描述我们暂时接受的、关于语言—认知—现实关系的基本命题。

原则回答：

> **系统中有哪些最基本的关系成立？**

原则不直接规定具体说法。

---

## 4.2 Model｜模型

模型描述多个原则共同作用时，系统如何组织和流转。

模型回答：

> **系统是怎样运行的？**

原则定义边界。

模型提供结构。

---

## 4.3 Mechanism｜机制

机制描述某一次状态变化通过什么过程发生。

机制回答：

> **变化为什么、如何发生？**

例如：

- Comparison
    
- Attention Direction
    
- Framing
    
- Labeling
    
- Generation
    
- Counterfactual Simulation
    
- Pragmatic Inference
    

机制通常不是由认知语言工程发明，而是从心理学、认知科学、语言学和交互研究中提取。

---

## 4.4 Task｜任务

任务描述使用者当前真正需要完成的认知、沟通或行动目标。

例如：

- 澄清意图
    
- 发现问题
    
- 判断因果
    
- 做出选择
    
- 澄清概念
    
- 形成共识
    
- 委派任务
    
- 检查信念
    

工程流程应从 Task 开始，而不是从“我有哪些算子”开始。

---

## 4.5 Operator｜算子

认知语言算子是：

> **通过语言主动调用一种或多种认知、交互或行动机制，使系统从状态 S₀ 朝目标状态 S₁ 转换的可复用操作。**

基本结构：

**Operator = Preconditions + Linguistic Instruction + Mechanism + Expected State Change**

算子不是一句“好问题”。

算子是可以拥有多种语言实现的认知函数。

---

## 4.6 Pattern｜语言模式

Pattern 是某个 Operator 在具体语言中的实现形式。

例如：

**Difference Operator**

可以有：

- “你希望什么变得不同？”
    
- “如果只能改变一件事，你希望改变什么？”
    
- “现在和你期待的状态，最明显的差异是什么？”
    

不同 Pattern 可以服务同一个 Operator。

---

## 4.7 Protocol｜协议

Protocol 是：

> **为了完成一个完整任务，而按照特定顺序组织多个 Operator 的流程。**

例如：

**Intent Formulation Protocol**

可能为：

**Difference → Specificity → Boundary → Criteria**

协议不仅用于增强效果，也用于抵消单个算子的偏差。

---

## 4.8 Application｜应用

Application 是 Protocol 在现实领域中的具体使用。

例如：

- 自我认知
    
- 学习
    
- 写作
    
- 决策
    
- 谈判
    
- 管理
    
- 产品设计
    
- Prompt Engineering
    
- Context Engineering
    
- Agent Harness
    

---

## 4.9 Evaluation｜评估

任何认知语言组件都必须能够回答：

> **它到底有没有帮助？**

评估可能包括：

- 信息具体度是否提高；
    
- 歧义是否降低；
    
- 是否发现更多关键变量；
    
- 是否更快完成任务；
    
- 判断准确率是否改善；
    
- 是否产生新的偏差；
    
- 是否增加认知负担；
    
- 是否提高协作或执行成功率。
    

认知语言工程拒绝仅凭“听起来很聪明”评价语言技巧。

---

# 5. Foundations v0.2

当前暂定六条基础原则。

## P1. Representation Principle｜表征原理

> **现实不等于内部表征，内部表征也不等于语言表达。**

形式化：

**World ≠ Internal Representation ≠ Linguistic Representation**

“地图不是疆域”属于这一原则。

工程意义：

不要把语言标签直接当作现实结构。

---

## P2. Context Principle｜语境原理

> **语言的实际意义不能脱离其使用语境。**

一个 Pattern 的效果至少取决于：

- 使用者是谁；
    
- 接收者是谁；
    
- 当前认知状态；
    
- 前文；
    
- 目标；
    
- 角色关系；
    
- 共享背景。
    

因此：

**Pattern ≠ Sentence Alone**

更合理的是：

**Pattern = Linguistic Form + Context + Role + State**

---

## P3. Common Ground Principle｜共同背景原理

> **有效沟通依赖参与者当前能够共同使用的背景信息。**

共同背景不是静态知识库。

它会在互动中持续更新。

这也是 Context Engineering、长期 Agent memory 和需求澄清的重要理论基础。

---

## P4. Language-as-Action Principle｜语言行动原理

> **语言不仅表征现实，也能够直接执行行动。**

例如：

- 请求
    
- 承诺
    
- 指派
    
- 宣布
    
- 警告
    
- 协商
    
- 建立规则
    

因此，认知语言工程不仅研究“怎样想清楚”，还研究“怎样通过语言改变社会或技术状态”。

---

## P5. Language-Mediated Cognition Principle｜语言介导认知原理

> **语言可以作为认知工具参与并改变部分认知过程，但语言并不是唯一的认知媒介。**

认知语言工程不采取“没有语言就没有思维”这样的强命题。

它只要求承认：

在某些任务中，改变语言形式能够改变：

- 注意；
    
- 分类；  
    -检索；
    
- 推理；
    
- 自我调节；
    
- 决策；
    
- 记忆。
    

---

## P6. Form-Sensitivity Principle｜形式敏感原理

> **即使内容相近甚至逻辑等价，不同语言形式仍可能导致不同的认知加工和行为结果。**

这条原则是认知语言工程能够存在的重要前提。

如果所有等价语言形式永远产生完全相同的认知结果，那么语言工程几乎没有意义。

---

# 6. Core Models v0.1

当前保留四个核心模型和一个总闭环。

## M1. Representation Model｜表征模型

**World  
→ Perception  
→ Internal Representation  
→ Linguistic Representation**

同时存在反向作用：

**Language  
→ Internal Representation  
→ Attention / Interpretation  
→ Action**

该模型主要解释：

> 语言操作的对象究竟是什么。

---

## M2. Cognitive Intervention Model｜认知干预模型

核心形式：

**C₀ → L → M → C₁**

其中：

- C₀：当前认知状态
    
- L：语言干预
    
- M：被调用的认知机制
    
- C₁：新的认知状态
    

传统分析容易使用：

**Question → Answer**

认知语言工程更关注：

**State Before → Language → Mechanism → State After**

---

## M3. Interaction Model｜交互模型

形式：

**S₁ + CG₀  
→ Utterance  
→ Interpretation  
→ S₂ + CG₁**

其中：

- S：参与者认知状态
    
- CG：Common Ground
    
- Utterance：具体语言行为
    

该模型主要解释：

- 为什么语境重要；
    
- 为什么一句话不能脱离互动评价；
    
- 为什么沟通需要不断管理共同背景。
    

---

## M4. Linguistic Action Model｜语言行动模型

形式：

**Intent  
→ Speech Act  
→ Commitment / Response  
→ World-State Change**

用于解释：

- 请求
    
- 承诺
    
- 委派
    
- 协议
    
- Agent instructions
    
- 组织协调
    

---

## M0. Human–Language Feedback Loop｜总闭环

完整闭环：

**Reality  
→ Representation  
→ Language  
→ Cognition / Interaction / Action  
→ New Reality  
→ Feedback**

认知语言工程研究的最终对象不是语言本身，而是：

> **人如何借助语言更好地改变自己的认知状态、与他人协调并影响现实。**

---

# 7. Mechanism Map v0.1

当前机制暂分五组。

## A. Representation Mechanisms

改变：

> 我们脑中形成什么样的表征。

包括：

- Labeling
    
- Abstraction
    
- Chunking / Compression
    
- Metaphorical Mapping
    

---

## B. Attention & Search Mechanisms

改变：

> 我们接下来往哪里寻找信息。

包括：

- Attention Direction
    
- Comparison / Contrast
    
- Framing
    
- Question-Induced Search
    

核心假设：

> **Question = Information Request + Attention Allocation**

---

## C. Generation & Reorganization Mechanisms

改变：

> 人如何产生新的认知内容。

包括：

- Generation
    
- Self-Explanation
    
- Perspective Shift
    
- Counterfactual Simulation
    

---

## D. Self-Regulation Mechanisms

改变：

> 人如何控制自己的认知过程。

包括：

- Verbal Self-Regulation
    
- Cognitive Offloading / Externalization
    

---

## E. Interaction & Action Mechanisms

改变：

> 人与人、人和系统之间的状态。

包括：

- Pragmatic Inference
    
- Common-Ground Updating
    
- Commitment Formation
    
- Coordination
    

---

# 8. Operator Library v0.1

当前已经形成两个较明确的 Operator Families。

## 8.1 Counterfactual Operator Family

Primary Mechanism：

**Counterfactual Simulation**

当前包含：

### Removal Operator

如果没有 X，会怎样？

目标：

测试必要性。

### Replacement Operator

如果把 X 换成 Y，会怎样？

目标：

分离目标与当前实现路径。

### Inversion Operator

如果结果完全相反呢？

目标：

暴露隐藏假设。

### Constraint Release Operator

如果这个限制不存在呢？

目标：

从受约束方案中恢复原始意图。

### Alternative-History Operator

如果当时改变一个关键条件，会在哪里开始产生不同？

目标：

探索候选因果节点。

---

## 8.2 Comparison / Contrast Operator Family

Primary Mechanism：

**Comparison / Contrast**

当前包含：

### Difference Operator

哪里不同？

典型 Pattern：

> “你希望什么变得不同？”

### Gap Operator

具体差在哪里？

### Benchmark Operator

你在和什么比较？

### Similarity Operator

它们真正相同的是什么？

### Trade-off Operator

提高 A 需要牺牲什么？

---

# 9. Operator 标准规格

每个 Operator 至少记录以下字段：

1. **Name**
    
2. **Task**
    
3. **Preconditions**
    
4. **Primary Mechanism**
    
5. **Secondary Mechanisms**
    
6. **Language Patterns**
    
7. **Expected State Change**
    
8. **Expected Output**
    
9. **Failure Conditions**
    
10. **Possible Distortion / Trade-off**
    
11. **Confusable With**
    
12. **Application Scenarios**
    
13. **Evidence Status**
    
14. **Evaluation Method**
    

这是 Operator Library 的统一接口。

---

# 10. Protocol Design

Protocol 的基本职责不是“多问几个问题”。

Protocol 要完成三件事：

1. 把复杂任务拆成连续认知状态转换；
    
2. 为不同状态选择合适 Operator；
    
3. 用后续 Operator 校正前面 Operator 可能产生的偏差。
    

例如：

## Intent Formulation Protocol v0.1

**Difference  
→ Specificity  
→ Boundary  
→ Criteria**

目标：

**模糊不满  
→ 可描述差异  
→ 清晰对象  
→ 明确边界  
→ 可判断目标**

---

## Belief Check Protocol v0.1

**Specificity  
→ Counterexample  
→ Perspective  
→ Counterfactual  
→ Evidence**

目标：

把一个未经检查的判断转换成更具体、更有边界、更可证伪的判断。

---

# 11. Trade-off Principle for Engineering

所有认知语言干预都必须同时记录：

**Intended Effect**

和：

**Possible Distortion**

原因是语言操作通常不是“无损增强”。

例如：

- 抽象提高迁移，但损失细节；
    
- Labeling 提高分类效率，但可能制造本质化；
    
- Framing 帮助组织问题，也可能偏置判断；
    
- Metaphor 帮助理解，也可能错误迁移结构；
    
- Externalization 降低工作记忆负担，也可能制造依赖；
    
- Attention Direction 强化某种搜索，也意味着其他方向得到更少资源。
    

因此：

> **没有脱离任务和状态的“最佳问题”。**

更准确的工程对象是：

**Task × State × Operator Fit**

---

# 12. Evidence Framework v0.1

每条 Principle、Mechanism、Operator 都需要标记证据状态。

暂定：

**E0 — Hypothesis**  
合理假设，目前主要来自理论推导或内部实验。

**E1 — Practice / Theory**  
存在理论传统或大量实践使用。

**E2 — Empirical**  
存在明确实证研究支持。

**E3 — Review / Replication**  
存在多项重复研究、系统综述或 meta-analysis。

**E4 — Mature**  
跨任务、跨方法、跨领域均获得较稳定支持。

注意：

证据等级描述的是：

> **我们对某个 claim 的信心水平。**

它不是 Operator 的价值评分。

---

# 13. 知识进入体系的规则

任何新知识进入认知语言工程核心库之前，都应经过：

### Source Check

来源是什么？

### Claim Check

原始材料真正声称了什么？

### Evidence Check

支持程度如何？

### Boundary Check

什么情况下不成立？

### Distortion Check

会产生什么副作用？

### Architecture Check

属于 Principle、Model、Mechanism、Operator、Pattern 还是 Protocol？

### Engineering Check

它具体帮助人做什么？

### Evaluation Check

怎样判断它有效？

核心原则：

> **不继承流派，只继承经过拆解和验证后的命题。**

因此，NLP、General Semantics、认知语言学、修辞学、心理学、Prompt Engineering 等都属于**知识来源**，而不是认知语言工程必须整体接受的理论包。

---

# 14. 核心研究方法

认知语言工程后续采用四种并行方法。

## 14.1 Literature Mining

从相关领域寻找已有理论、机制、实证结果和失败案例。

---

## 14.2 Conceptual Engineering

对零散概念重新命名、划界、统一接口。

目标不是发明术语，而是：

> 让原本模糊的认知过程变得可分析、可讨论、可组合。

---

## 14.3 Operator Engineering

将机制转化为可主动调用的工程接口。

---

## 14.4 Empirical Testing

比较不同：

- Pattern
    
- Operator
    
- Protocol
    

是否真的导致不同认知结果。

---

# 15. 当前核心研究问题

当前阶段优先研究：

### Q1

哪些机制真正适合成为认知语言工程的基础机制？

### Q2

机制和 Operator 之间怎样建立稳定映射？

### Q3

一个 Operator 在什么状态下有效，在什么状态下失效？

### Q4

语言 Pattern 改变以后，Operator 是否仍保持同一功能？

### Q5

多个 Operator 如何组合成稳定 Protocol？

### Q6

怎样测量“认知状态改变”？

### Q7

LLM 如何成为认知语言工程的动态执行环境，而不仅是答案生成器？

---

# 16. 当前产物体系

认知语言工程未来不以一本书作为唯一载体，而采用一个持续增长的知识系统。

核心产物包括：

## Core Spec

冻结架构和核心定义。

## Foundation Registry

维护基础原理。

## Model Registry

维护系统模型。

## Mechanism Library

维护认知、语言与交互机制。

## Operator Library

维护可调用认知操作。

## Pattern Library

维护不同 Operator 的语言实现。

## Protocol Library

维护完整认知任务流程。

## Application Cases

记录真实应用案例。

## Evaluation Bench

用于测试 Operator 和 Protocol 的实际效果。

---

# 17. 当前版本冻结项

v0.3 暂时冻结：

1. 核心目的；
    
2. Explanation Stack / Engineering Stack 双栈结构；
    
3. Principle / Model / Mechanism / Task / Operator / Pattern / Protocol / Application / Evaluation 九个核心对象；
    
4. Mechanism 与 Operator 为多对多关系；
    
5. Operator 是解释体系与工程体系的桥梁；
    
6. 所有组件必须记录边界与副作用；
    
7. 新内容优先填充现有骨架，不轻易修改骨架。
    

---

# 18. 暂不冻结项

以下内容允许持续变化：

- Foundation 的最终数量；
    
- Model 的最终数量；
    
- Mechanism 分类；
    
- Operator Family；
    
- Protocol；
    
- Evidence 等级细则；
    
- 应用领域；
    
- 测试方法。
    

---

# 19. 一句话定义

最终可以把认知语言工程暂时定义为：

> **认知语言工程是一套通过研究、设计、组合和验证语言结构，主动改善人的认知、表达、协作与行动能力的工程体系。**

其最核心的工程闭环是：

**Human Purpose  
→ Cognitive / Communicative Task  
→ Language Intervention  
→ State Change  
→ Real-World Effect  
→ Feedback  
→ Better Language Design**

认知语言工程最终追求的不是：

**更漂亮的语言。**

而是：

> **更有能力的人。**