# 认知语言工程

**提升人对语言的主动控制能力，使语言更有效地服务于思考、表达、协作与行动。**

这是一部持续更新的在线研究手册。当前内容以核心规范、状态模型和 Transition Registry 为主，还不是完成的教材。

## 推荐阅读顺序

1. [核心目的](PURPOSE.md)：研究的主线。
2. [核心规范 v0.3](CORE_SPEC.md)：解释栈、工程栈和概念关系。
3. [M1 表征状态模型](models/M1.md)。
4. [M2 个体认知状态模型](models/M2.md)。
5. [M3 共享认知与互动状态模型](models/M3.md)。
6. [M4 语言行动状态模型](models/M4.md)。

## 当前版本与内容状态

项目初始化快照：**project-v0.1.0，2026-10-01**。Core Spec 仍保留自身版本 v0.3。

!!! note "正式基线的含义"
    六份上传文件作为当前研究的工作基线，内容原样保留。原文中的 Freeze Candidate、Primitive Candidate 等限定也保留。接受为工作基线不意味着每个研究主张均已被实证验证。

最近讨论整理为[期望变化形成](research/desired-change-formation.md)与[目标形成](research/goal-formation.md)候选研究稿。[评价标准形成](research/criteria-formation.md)是下一项研究，尚未形成结论。

阅读正式规范前，可先查看[已知待对齐项](project/BASELINE.md)。继续协作时从[当前进度](project/STATUS.md)开始。

## 阅读与修改

左侧目录定位章节，页内目录定位条目，搜索查找术语和 Transition ID。正式正文与研究稿均在同一组 Markdown 文件中维护，由构建工具生成阅读页面。

在线阅读版本随发布更新；历史内容通过仓库的版本标签恢复。后续可在正文较稳定时增加 EPUB 或 PDF 导出。
