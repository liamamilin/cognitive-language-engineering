# 当前进度

更新时间：2026-10-01。项目快照：project-v0.1.0。

## 已接受并沉淀

- 用 Markdown 文档项目保存长期研究成果，用 Git 管理历史。
- 用户上传的核心目的、Core Spec v0.3、M1—M4 六份文件成为初始基线。
- 项目最终以在线电子书展示，后续提交到 GitHub，通过 GitHub Pages 发布阅读链接。
- 冻结表示正式工作基线；有理由时可在新版本修订，历史快照保留。

## 已整理的研究稿

- C-C6 Desired-Change Formation：区分差异、偏好、期望状态；整理 C-P16/C-P17 候选和路径。
- C-C7 Goal Formation：整理 C-P18 Goal Adoption 候选，区分 Goal、Means、Plan 和 Implementation Intention。
- 对话引文只登记为待核验；未继承对话中未经审查的证据等级。

## 待回写与未决问题

1. Core Spec 与独立 M1—M4 的名称、职责与边界需统一。
2. C-P16/C-P17/C-P18 尚未纳入 M2 正式 Registry；候选编号尚未正式接受。
3. Pattern、Operator 与 Micro-Protocol 的多对多映射需审查后回写。
4. Minimal Primitive Principle 待审查后进入规范。
5. Goal Adoption 的内部采纳与 M4 对外承诺需严格区分。
6. Reference Path 若参考已经被偏好，是否需要再次完整经过 Preference Formation？需要避免冗余必经步骤。
7. Difference Detection 不能被写成偏好形成的必要条件。
8. 研究稿引文的来源内容、主张匹配与适用边界需要核验。

## 下一步

研究 **C-C8 Criteria Formation**：从已形成的目标／评价对象，到用于判断好坏、进展或达成的标准表征。先检查 M2 已有条目，明确 Evaluation Criteria 与 M4 Acceptance Criteria 的边界，再判断是否需要新增 Primitive。

本轮结束应产出候选定义、状态变化、复用项、机制假设、反例和证据缺口；不预先冻结具体分解或新增编号。

## 发布状态

本地电子书构建配置已加入。尚未建立 GitHub 远程仓库、执行远程发布或生成真实在线链接。
