# 发布在线电子书

状态：发布方案已接受；实际 GitHub 仓库和在线链接尚未建立。

## 实现形式

Markdown → MkDocs Material → 静态阅读页面 → GitHub Pages。

在线电子书包含章节目录、页内导航、搜索、手机阅读和深色模式。它是网页阅读版；EPUB／PDF 导出可在后续正文更稳定时增加。

## 首次发布

1. 在 GitHub 创建用于此项目的仓库。项目目录建议名为 `cognitive-language-engineering`；是否公开由用户决定，Pages 可用性取决于账户与仓库配置。
2. 按根目录 README 初始化本地 Git，将项目推送到该仓库的 `main` 分支。
3. 在仓库 `Settings → Pages → Build and deployment → Source` 选择 `GitHub Actions`。
4. 在 Actions 页面手动运行 `Build and publish CLE book`，或推送下一次提交触发工作流。
5. 构建与部署完成后，从 Pages 设置或部署任务输出复制真实链接。

GitHub.com 项目站点通常为 `https://<username>.github.io/<repository>/`。这是地址模式，不是当前可访问的书籍链接。

## 后续更新

修改 Markdown，更新进度与变更记录，通过本地严格构建，再提交和推送。`main` 的推送触发构建及部署；PR 只检查构建，不发布。第一次打开 Pages 前若部署失败，完成 Pages 设置后重新运行工作流。

历史版本通过 Git 标签保存；当前配置只发布最新阅读版，尚未配置网页版本选择器。

首次部署后，可在 `mkdocs.yml` 补充真实 `site_url` 和 `repo_url`；初始化不填写虚构仓库或地址。

## 构建依赖

本包验证并固定 MkDocs 1.6.1、Material 9.7.7，详情记在根目录 `BUILD_REPORT.md`。依赖升级应单独构建验证后更新。

## 官方参考

- [MkDocs：Deploying your docs](https://www.mkdocs.org/user-guide/deploying-your-docs/)
- [Material for MkDocs：Publishing your site](https://squidfunk.github.io/mkdocs-material/publishing-your-site/)
- [GitHub：Deploying your website automatically](https://docs.github.com/en/get-started/start-your-journey/deploying-your-website-automatically)
